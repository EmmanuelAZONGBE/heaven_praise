<footer class="page_footer ds color section_padding_top_100 section_padding_bottom_10">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center"> <a href="./" class="logo vertical_logo">
        <img src="{{asset('assets/images/logo.png')}}" alt="">
    </a>
                <ul class="topmargin_40 inline-content small-text darklinks">
                    <li> <a href="#0" class="socicon-facebook text-icon">Facebook</a> </li>
                    <li> <a href="#0" class="socicon-twitter text-icon">Twitter</a> </li>
                    <li> <a href="#0" class="socicon-instagram text-icon">Instagram</a> </li>
                    <li> <a href="#0" class="socicon-google text-icon">Google</a> </li>
                    <li> <a href="#0" class="socicon-youtube text-icon">Youtube</a> </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<section class="ds color page_copyright section_padding_15">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="bottommargin_10"> <a class="social-icon socicon-facebook" href="#" title="Facebook"></a> <a class="social-icon socicon-twitter" href="#" title="Twitter"></a> <a class="social-icon socicon-youtube" href="#" title="Youtube"></a> <a class="social-icon socicon-google"
                        href="#" title="Google"></a> </div>
                <p class="small-text">&copy; Copyright Emmac Corporation 2023. Tous Droits Réservés.</p>
            </div>
        </div>
    </div>
</section>