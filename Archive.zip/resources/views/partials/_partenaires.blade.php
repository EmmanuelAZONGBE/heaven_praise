<!-- partners -->
<div class="row">
    <div class="col-12">
        <div class="partners owl-carousel">
            <a href="#" class="partners__img">
                <img src="PlayerTemplate/img/partners/alleluia-world-tv.png" alt="Alleluia World TV" title="Alleluia World TV">
            </a>

            <a href="#" class="partners__img">
                <img src="PlayerTemplate/img/partners/perseverance-gospel.png" alt="Perséverance Gospel" title="Perséverance Gospel">
            </a>

        </div>
    </div>
</div>
<!-- end partners -->