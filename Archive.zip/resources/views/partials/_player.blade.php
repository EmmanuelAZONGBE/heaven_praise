<!----Audio Player Section---->
<div class="ms_player_wrapper">
	<div class="ms_player_close">
		<i class="fa fa-angle-up" aria-hidden="true"></i>
	</div>
	<div class="player_mid">
		<div class="audio-player">
			<div id="jquery_jplayer_1" class="jp-jplayer"></div>
			<div id="jp_container_1" class="jp-audio" role="application" aria-label="media player">
				<div class="player_left">
					<div class="ms_play_song">
						<div class="play_song_name">
							<a href="javascript:void(0);" id="playlist-text">
								<div class="jp-now-playing flex-item">
									<div class="jp-track-name"></div>
									<div class="jp-artist-name"></div>
								</div>
							</a>
						</div>
					</div>
					<div class="play_song_options">
						<ul>
							{{-- <li>
								<a href="index.html#">
									<span class="song_optn_icon"><i class="ms_icon icon_fav"></i></span>
									Add To Favourites
								</a>
							</li> --}}
							<li>
								<a href="index.html#">
									<span class="song_optn_icon"><i class="ms_icon icon_playlist"></i></span>
									Ajouter à ma Playlist
								</a>
							</li>
							<li>
								<a href="index.html#">
									<span class="song_optn_icon"><i class="ms_icon icon_share"></i></span>
									Partager
								</a>
							</li>
						</ul>
					</div>
					<span class="play-left-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
				</div>
				<!----Right Queue---->
				<div class="jp_queue_wrapper">
					<span class="que_text" id="myPlaylistQueue"><i class="fa fa-angle-up" aria-hidden="true"></i> Ma liste</span>
					<div id="playlist-wrap" class="jp-playlist">
						<div class="jp_queue_cls">
							<i class="fa fa-times" aria-hidden="true"></i>
						</div>
						<h2>File d'attente</h2>
						<div class="jp_queue_list_inner">
							<ul>
								<li>&nbsp;</li>
							</ul>
						</div>
						<div class="jp_queue_btn">
							<a href="javascript:;" class="ms_clear" data-toggle="modal" data-target="#clear_modal">Effacer</a>
							<a href="https://kamleshyadav.com/html/miraculous/html/Bootstrap4/version1/clear_modal" class="ms_save" data-toggle="modal" data-target="#save_modal">Enregistrer</a>
						</div>
					</div>
				</div>
				<div class="jp-type-playlist">
					<div class="jp-gui jp-interface flex-wrap">
						<div class="jp-controls flex-item">
							<button class="jp-previous" tabindex="0"><i class="ms_play_control"></i></button>
							<button class="jp-play" tabindex="0"><i class="ms_play_control"></i></button>
							<button class="jp-next" tabindex="0"><i class="ms_play_control"></i></button>
						</div>
						<div class="jp-progress-container flex-item">
							<div class="jp-time-holder">
								<span class="jp-current-time" role="timer" aria-label="time">&nbsp;</span>
								<span class="jp-duration" role="timer" aria-label="duration">&nbsp;</span>
							</div>
							<div class="jp-progress">
								<div class="jp-seek-bar">
									<div class="jp-play-bar">
										<div class="bullet"></div>
									</div>
								</div>
							</div>
						</div>
						<div class="jp-volume-controls flex-item">
							<div class="widget knob-container">
								<div class="knob-wrapper-outer">
									<div class="knob-wrapper">
										<div class="knob-mask">
											<div class="knob d3">
												<span></span>
											</div>
											<div class="handle"></div>
											<div class="round">
												<img src="{{asset('player/images/svg/volume.svg')}}" alt="">
											</div>
										</div>
									</div>
									<!-- 
									<input>
									</input>
									 -->
								</div>
							</div>
						</div>
						<div class="jp-toggles flex-item">
							<button class="jp-shuffle" tabindex="0" title="Shuffle"><i class="ms_play_control"></i></button>
							<button class="jp-repeat" tabindex="0" title="Repeat"><i class="ms_play_control"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--main div-->
</div>

<!----Queue Clear Model ---->
<div class="ms_clear_modal">
	<div id="clear_modal" class="modal  centered-modal" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<button type="button" class="close" data-dismiss="modal"><i class="fa_icon form_close"></i></button>
				<div class="modal-body">
					<h1>Êtes-vous sûr de vouloir effacer votre file d'attente ?</h1>
					<div class="clr_modal_btn">
						<a href="index.html#">tout effacer</a>
						<a href="index.html#">Annuler</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!----Queue Save Modal---->
<div class="ms_save_modal">
	<div id="save_modal" class="modal  centered-modal" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<button type="button" class="close" data-dismiss="modal"><i class="fa_icon form_close"></i></button>
				<div class="modal-body">
					<h1>Log in to start sharing your music!</h1>
					<div class="save_modal_btn">
						<a href="index.html#"><i class="fa fa-google-plus-square" aria-hidden="true"></i> continue with google </a>
						<a href="index.html#"><i class="fa fa-facebook-square" aria-hidden="true"></i> continue with facebook</a>
					</div>
					<div class="ms_save_email">
						<h3>or use your email</h3>
						<div class="save_input_group">
							<input type="text" placeholder="Enter Your Name" class="form-control">
						</div>
						<div class="save_input_group">
							<input type="password" placeholder="Enter Password" class="form-control">
						</div>
						<button class="save_btn">Log in</button>
					</div>
					<div class="ms_dnt_have">
						<span>Dont't have an account ?</span>
						<a href="javascript:;" class="hideCurrentModel" data-toggle="modal" data-target="#myModal">Register Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

